﻿public class FootNote
{
    public string? Code { get; set; }
    public string? Text { get; set; }
}